function M = zerodiag(M)

M = utils.putdiag(M,0);
